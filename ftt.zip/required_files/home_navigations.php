<li><a href="#home-section" class="nav-link">Home</a></li>
<li><a href="#update" class="nav-link">Update</a></li>
<li><a href="#services" class="nav-link">Services</a></li>
<li><a href="#tour_package" class="nav-link">Tour Package</a></li>
<li><a href="#destinations" class="nav-link">New Destinations</a></li>
<li><a href="photos.php" class="nav-link">Photos</a></li>
<li><a href="#contact-section" class="nav-link">Contact</a></li>
<li><a href="#other-services-offered" class="nav-link">Other Services Offered</a></li>