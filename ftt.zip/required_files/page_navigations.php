<li><a href="index.php#home-section" class="nav-link">Home</a></li>
<li><a href="index.php#update" class="nav-link">Update</a></li>
<li><a href="index.php#services" class="nav-link">Services</a></li>
<li><a href="index.php#tour_package" class="nav-link">Tour Package</a></li>
<li><a href="index.php#destinations" class="nav-link">New Destinations</a></li>
<li><a href="photos.php" class="nav-link">Photos</a></li>
<li><a href="index.php#contact-section" class="nav-link">Contact</a></li>
<li><a href="index.php#other-services-offered" class="nav-link">Other Services Offered</a></li>
