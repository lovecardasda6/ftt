<li><a href="home.php" class="nav-link">Home</a></li>
<li><a href="update.php" class="nav-link">Update</a></li>
<li><a href="services.php" class="nav-link">Services</a></li>
<li><a href="tour_package.php" class="nav-link">Tour Package</a></li>
<li><a href="tour_destinations.php" class="nav-link">New Destinations</a></li>
<li><a href="photos.php" class="nav-link">Photos</a></li>
<li><a href="contacts.php" class="nav-link">Contact</a></li>
<li><a href="other_services.php" class="nav-link">Other Services Offered</a></li>
<li><a href="user_management.php" class="nav-link">User Management</a></li>
<li><a href="./require_files/logout.php" class="nav-link">Logout</a></li>